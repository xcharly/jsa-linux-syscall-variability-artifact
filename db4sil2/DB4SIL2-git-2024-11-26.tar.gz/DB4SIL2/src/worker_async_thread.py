import os
import json
import threading
from datetime import datetime
import shutil
import collections
import datetime
import platform
import tarfile
import db4sil2config as cfg
import sock_conn_async as sc
import logger as l
import process_trace
import csv_generator
import multiprocessing

import asyncio, socket

def tardir(path, tar_name):
    with tarfile.open(tar_name, "w:gz") as tar_handle:
        for root, dirs, files in os.walk(path):
            for file in files:
                tar_handle.add(os.path.join(root, file))

def dir_checks(path, syscalls):
    """
    remove temporary working directory, in case server has
    been interrupted and create new dir structure
    """
    if os.path.exists(os.path.join(path, 'syscalls')):
        shutil.rmtree(os.path.join(path, 'syscalls'))

    for syscall in syscalls:
        if not os.path.exists('%s/syscalls/traces/%s' % (path, syscall)):
            os.makedirs('%s/syscalls/traces/%s' % (path, syscall))
            os.makedirs('%s/syscalls/traces/%s/unique_traces' % (path, syscall))
            os.makedirs('%s/syscalls/timings/%s' % (path, syscall))
            os.makedirs('%s/syscalls/meta/%s' % (path, syscall))
    os.makedirs('%s/syscalls/meta/PER_TEST' % (path))




def post_process(tracefile, search_list, slist, data_path, del_raw, minfo, logger_queue):


        l.log_a_msg("Handline Trace %s" % tracefile, "INFO", \
                        logger_queue, "conn: %s" % minfo['hostname'])
#        testname = process_trace.strip_testname(data_path, tracefile)

        found_syscalls = process_trace.search_syscalls(tracefile, \
                                                       data_path, \
                                                       search_list[1:], \
                                                       minfo['job_name'], \
                                                       platform.uname().node, \
                                                       minfo['hostname'], \
                                                       logger_queue, \
                                                       minfo['kernel'])

        if found_syscalls == 1:
            return

        process_trace.check_if_redundant(data_path, \
                                         found_syscalls, \
                                         slist, \
                                         del_raw)

        l.log_a_msg("Trace Done %s" % tracefile, "INFO", \
                logger_queue, "test_server")

        if del_raw:   # raw tracing data may be kept for debugging
            os.system("rm {0}/raw/{1}".format(data_path, tracefile))



async def handle_data(client, loop, minfo, syscalls, del_raw, logger_queue):
    num_runs_done = 0
    current_t = datetime.datetime.now()
    formatted_dt = current_t.strftime("%Y-%m-%d_%H%M%S%f")

    test_dir = "%s/%s_%s" % (minfo['hostname'], minfo['job_name'], formatted_dt)
    data_path = os.path.join(os.getcwd(), 'data', "%s" % test_dir)
    os.makedirs(os.path.join(data_path, 'raw'))
    with open("%s/info.json" % (data_path), "w") as fp:
        json.dump(minfo, fp)

    slist = collections.defaultdict(lambda: collections.defaultdict(list))
    dir_checks(data_path, syscalls)
    run = True

    search_list = ''
    for syscall in syscalls:
        search_list = r"{0}|{1}\(\);?".format(search_list, syscall)

    if minfo['nfs'] == 'no':
        await sc.send_data(loop, client, 'Go')
    else:
        await sc.send_data(loop, client, 'data/%s/raw/' % (test_dir))

    trace_list = []
    procs = []
    count = 0

    while(True):
        data_id, payload = await sc.receive_data(loop, client)

        if data_id == sc.data_identifiers['name']:
            tracefile = payload

        if data_id == sc.data_identifiers['trace']:
            if minfo['nfs'] == 'no':
                with open('%s/raw/%s' % (data_path, tracefile[2:]), 'w') as f:
                    f.write(payload)

                fname = tracefile[2:]
#                post_process(tracefile[2:], search_list, slist, data_path, del_raw,
#                             minfo, logger_queue)
            else:
                fname = tracefile.split('/')[-1:][0]
#                post_process(fname, search_list, slist, data_path, del_raw,
#                             minfo, logger_queue)
            trace_list.append(fname)

        if data_id == sc.data_identifiers['end']:
            print('end of trace job')
            client.close()
            if not os.path.exists('../results/%s' % minfo['hostname']):
                os.makedirs('../results/%s' % minfo['hostname'])
            break

    for n, trace in enumerate(trace_list):
        print("Process trace %d/%s" % (n + 1, minfo['runs']))
        proc = multiprocessing.Process(target=post_process, args=(trace, search_list,
                            slist, data_path, del_raw, minfo, logger_queue))
        proc.start()
        procs.append(proc)
        multiprocessing.active_children()

    for proc in procs:
        proc.join()

    tar_name= data_path.split("/")[-1]
    tar = tarfile.open("../results/" + minfo['hostname'] + "/"
                       + tar_name + ".tar.gz", "w:gz")
    tar.add(data_path, arcname=tar_name)
    tar.close()

    csv_generator.generate(syscalls, data_path, minfo['hostname'])
    shutil.move(data_path, '../results/%s' % minfo['hostname'])
    #shutil.rmtree(data_path)



async def handle_client(client, loop, config_file, logger_queue):
    flag = False
    syscalls, \
    del_raw, \
    tested_kernels = cfg.get_postprocessing_config(config_file, "test_server", \
                                            logger_queue)

    data_id, payload = await sc.receive_data(loop, client)
    if payload != sc.key_message:
        print('Wrong key message')
        return
    else:
        await sc.send_data(loop, client, 'Connection accepted')
        print('Connection accepted')

        data_id, payload = await sc.receive_data(loop, client)
        if data_id == sc.data_identifiers['data']:
            minfo = json.loads(payload)
            for kernel in tested_kernels:
                if kernel in minfo['kernel']:
                    await handle_data(client, loop, minfo, \
                                        syscalls[minfo['arch']], \
                                        del_raw, \
                                        logger_queue)
                    flag = True
                    break

            if flag == False:
                l.log_a_msg("Wrong Kernel Version - Abort!", "INFO", \
                                    logger_queue, minfo['hostname'])

                await sc.send_data(loop, client, 'Abort')
                return


        else:
            l.log_a_msg("Init data was not sent!", "ERROR", \
                                        logger_queue, self.conn_name)
            await sc.send_data(loop, client, 'Abort')


    client.close()
