import os
import shutil
import csv
import glob
import pandas as pd

def collectMd5s(file, systemcall):
    allHash = []
    addr_all = []
    sysc = systemcall.split('_')[-1]
    with open(file, 'r') as file_iterator:
        for line in file_iterator:
            if '## db4sil2_sys_start:' in line and sysc in line:
                addr = line.split(':')[-1]
                addr = addr.replace(' ##\n', '')
                addr_all.append(addr)
                next_line = next(file_iterator)
                while sysc not in next_line and next_line.startswith("S:") == False:
                    next_line = next(file_iterator)
                while next_line.startswith("E:") == False:
                    next_line = next(file_iterator)
                if next_line.startswith("E:"):
                    hash = next_line.split(':')
                    allHash.append(hash[-1])
    return allHash, addr_all


def manageMd5s(folder, systemcall, md5s, host, sys_ids):
    for sys_id in sys_ids:
        if os.path.isfile("../results/{0}/{1}_{2}_{3}.csv".format(host, systemcall, sys_id, folder)):
            write_header = False
        else:
            write_header = True

        with open ("../results/{0}/{1}_{2}_{3}.csv".format(host, systemcall, sys_id, folder),'a') as sys_file:
            writer = csv.writer(sys_file)
            if (write_header == True):
                writer.writerow([folder])

            hash = md5s[-1]
            writer.writerow([hash[:-1]]) # To delete \n from the string
        sys_file.close()

def generate(systemcalls, path, host):
    dir_name = "{0}/syscalls/meta/PER_TEST/".format(path)
    base_name = os.path.basename(path)
    files = os.listdir(dir_name)
    for file in files:
        for systemcall in systemcalls:
            hash_values = []
            hash_values, sys_addr = collectMd5s(dir_name+file, systemcall)
            if len(hash_values) != 0:
                manageMd5s(base_name,systemcall,hash_values, host, sys_addr)
