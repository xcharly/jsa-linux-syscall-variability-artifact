"""
Helper functions to process ftrace output.
"""

import re
import datetime
import os
import hashlib
import collections
import ply.lex as lex
import shutil
import ftracelexer
import logger as l

# reused function from http://stackoverflow.com/questions/3431825/generating-a-md5-checksum-of-a-file/3431838#3431838
def md5(path, name):
    """
    Calculate MD5 sum of a file with name fname.
    """
    thash = hashlib.md5()
    with open(os.path.join(path, name), "rb") as filep:
        for chunk in iter(lambda: filep.read(4096), b""):
            thash.update(chunk)
    return thash.hexdigest()


def _md5(path, name):
    """
    Calculate MD5 sum of a file with name fname.
    """
    thash = hashlib.md5()
    with open(os.path.join(path, name), "r") as fp:
        data = fp.readline().strip()
        thash.update(data.encode('UTF-8'))
    return thash.hexdigest()[:12]

def generate_filenames(path, found_syscall, hostname):
    """
    Names of raw traces/timings/meta data are mixture of current time stamp
    and hostname.
    """
    current_t = datetime.datetime.now()
    outtracefile = "{0}/syscalls/traces/{1}/{2}".format(path, found_syscall, \
                                       current_t.strftime("%Y-%m-%d_%H%M%S%f"))
    timingfile = "{0}/syscalls/timings/{1}/{2}_{3}".format(path, found_syscall, \
                                       hostname, \
                                       current_t.strftime("%Y-%m-%d_%H%M%S%f"))
    metafile = "{0}/syscalls/meta/{1}/{2}_{3}".format(path, found_syscall, \
                                       hostname, \
                                       current_t.strftime("%Y-%m-%d_%H%M%S%f"))
    return outtracefile, timingfile, metafile

def generate_filenames_wq(path, found_wq, found_func, hostname):
    """
    Names of raw traces/timings/meta data are mixture of current time stamp
    and hostname.
    """
    if not os.path.exists('%s/wq/traces/%s/%s' % (path,found_wq,found_func)):
        os.makedirs('%s/wq/traces/%s/%s' % (path, found_wq,found_func))
        os.makedirs('%s/wq/meta/%s/%s' % (path, found_wq,found_func))

    current_t = datetime.datetime.now()
    outtracefile = "{0}/wq/traces/{1}/{2}/{3}".format(path, found_wq, \
                                       found_func,
                                       current_t.strftime("%Y-%m-%d_%H%M%S%f"))

    metafile = "{0}/wq/meta/{1}/{2}/{3}_{4}".format(path, found_wq, \
                                       found_func, \
                                       hostname, \
                                       current_t.strftime("%Y-%m-%d_%H%M%S%f"))
    return outtracefile, metafile

def write_buf_to_file(filename, buf):
    """
    Write the buffer (trace, meta, etc.) to a given file.
    """
    with open(filename, "w") as filep:
        for line in buf:
            filep.write(line)

def check_if_redundant(path, filelist, slist, del_raw):
    """
    If the hash of this traceing data is unknown we found a new unique trace.
    If it is already known we don't store it, since it is not unique.
    """

    for tfile in filelist:
        fhash = md5(path, tfile)
        syscall = tfile.split('/')[-2]
        unique_name = tfile.split('/')[-1]

        if fhash in list(slist[syscall]):
            if del_raw:
                os.system("rm {0}".format(tfile))
        else:
            slist[syscall][fhash].append(unique_name)
            src = "%s" % tfile
            if "syscalls" in tfile:
                dst = "%s/syscalls/traces/%s/unique_traces/%s" % (path, syscall, fhash)
            else:
                if not os.path.exists("{0}/unique_traces".format(os.path.split(tfile)[0])):
                    os.makedirs("{0}/unique_traces".format(os.path.split(tfile)[0]))
                dst = "{0}/unique_traces/{1}".format(os.path.split(tfile)[0], fhash)
            shutil.copy(src, dst)
            if del_raw:
                os.system("rm {0}".format(tfile))
    return


def write_outfile(outfile, outbuf):
    """
    Write content of outbuf into outfile.
    """
    with open(outfile, "w") as fp_out:
        for tline in outbuf:
            fp_out.write(tline)

def read_tracebuf(tfile, workername, loggerq):
    """
    Read the raw trace from tfile and store it in a buffer. In addition
    certain events like task switches and interrupts are marked to simplyfy the
    processing later on.
    """
    try:
        fp_trace = open(tfile)
    except OSError as err:
        l.log_a_msg("Unable to open tracefile: {0}".format(tfile), "ERROR", \
                    loggerq, workername)
        l.log_a_msg(err, "ERROR", loggerq, "ftrace_session")
        return 1

    tracebuf = ''
    for line in fp_trace:
        # skip comments and dash-lines
        if re.search("^#", line) or re.search("^\n$", line):
            continue
        elif re.search("-----------", line):
            line = next(fp_trace)
            tracebuf += "##TASK_SWITCH: {0}##\n".format(\
                                                 line.split(')')[1].strip())
            line = next(fp_trace)
        elif re.search("db4sil2_sys_start|db4sil2_sys_end|workqueue_execute_start", line):
            line = line[4:]
            columns = line.split('|')
            tracebuf += columns[0]
            txt = columns[2][2:].replace('/*','##')
            txt = txt.replace('*/','##')
            tracebuf += txt
        elif "====>" in line:
            tracebuf += "##INTERRUPT_START##\n"
        elif "<====" in line:
            tracebuf += "##INTERRUPT_END##\n"
        else:
            try:
                line = line[4:]
                columns = line.split('|')
                #timingbuf.append(columns[1])
                tracebuf += columns[0]
                tracebuf += columns[2][2:]
            except IndexError:
                l.log_a_msg("Line caused a problem: {0}".format(tfile), "ERROR", \
                    loggerq, workername)
                #l.log_a_msg("LINE CAUSED A PROBLEM: %s" % tfile, "WARNING", \
                #            loggerq)

    fp_trace.close()
    return tracebuf


# tracefile: the raw tracefile
# syscalls: the syscalls that shall be extracted
# testname: the name of the testexecutable that produced this trace
def search_syscalls(tracefile, path, searchlist, testname, hostname, \
                    conn_name, loggerq, kversion):
    """
    search syscalls in a raw trace file and store them in separate files
    """

    pt_meta_file = "{0}/syscalls/meta/PER_TEST/{1}_{2}".format(path, hostname, tracefile)

    try:
        fp_tmeta = open(pt_meta_file, "w")
        fp_tmeta.write("{0}\n".format(testname))
    except OSError as err:
        l.log_a_msg("Handline Trace %s" % tracefile, "INFO", loggerq, "conn: %s" % conn_name)
        return 1

    file_name = os.path.join(path, 'raw', tracefile)
    tracebuf = read_tracebuf(file_name, conn_name, loggerq)

    lexer = lex.lex(module=ftracelexer.Ftracelexer(searchlist, \
                                                   conn_name, \
                                                   loggerq,
                                                   kversion))

    lexer.async_nesting = collections.defaultdict(int)
    lexer.async_balance = collections.defaultdict(list)
    lexer.num_braces = collections.defaultdict(int)
    lexer.trace_state = collections.defaultdict(str)
    lexer.wq_func = collections.defaultdict(str)
    lexer.currentpid = "NONE"
    lexer.input(tracebuf)


#	The next step is to parse the tokenized output. This is done in
#	a simple state machine:
#
#         START
#          |
#          v
#	+--------+  CALLSTART  +----------+  ASYNCSTART +-------------+
#       |        |------------>|          |------------>|             |
#       | INITIAL|             |IN_SYSCALL|             | ASYNC_EVENT |
#       |        |<------------|          |<------------|             |
#	+--------+  CALLEND    +----------+  ASYNCEND   +-------------+
#
#	This statemachine is implemented inside of the lexer! only the
#	tracing data gather in IN_SYSCALL is returned as well as the
#	start/end of meta-data.

    found_list = []
    nrspaces = collections.defaultdict(int)
    current_pid = 'NONE'
    flist = collections.defaultdict(dict)
    tout_buf = collections.defaultdict(list)
    meta_buf = collections.defaultdict(list)

    while True:
        tok = lexer.token()
        if not tok:
            break
        else:
            if tok.type == "CALLSTART":
                fp_tmeta.write("S:{0}:{1}:{2}\n".format(current_pid, \
                                                        tok.lineno, \
                                                        tok.value))

                tout_buf[current_pid].append("{0}\n".format(tok.value))
                meta_buf[current_pid].append("{0}\n".format(testname))

                tout_fname, \
                timing_fname, \
                meta_fname = generate_filenames(path, tok.value[:-2], hostname)

                flist[current_pid]['tout_fname'] = tout_fname
                flist[current_pid]['timing_fname'] = timing_fname
                flist[current_pid]['meta_fname'] = meta_fname

            elif tok.type == "CALLEND":
                if flist[current_pid]:

                    write_outfile(flist[current_pid]['tout_fname'], \
                                  tout_buf[current_pid])

                    thash = md5(path, flist[current_pid]['tout_fname'])
                    meta_buf[current_pid].append("TRACE HASH: {0}\n".format( \
                                                                        thash))

                    write_outfile(flist[current_pid]['meta_fname'], \
                                  meta_buf[current_pid])

                    found_list.append(flist[current_pid]['tout_fname'])

                    fp_tmeta.write("E:{0}:{1}:{2}\n".format(current_pid, \
                                                            tok.lineno, \
                                                            thash))

                    # Remove all data of this PID!
                    flist.pop(current_pid)
                    tout_buf.pop(current_pid)
                    meta_buf.pop(current_pid)

            elif tok.type == "CALLSTARTEND":
                fp_tmeta.write("S:{0}:{1}:{2}\n".format(current_pid, \
                                                        tok.lineno, \
                                                        tok.value))

                tout_fname, \
                timing_fname, \
                meta_fname = generate_filenames(path, tok.value[:-3], hostname)

                flist[current_pid]['tout_fname'] = tout_fname
                flist[current_pid]['timing_fname'] = timing_fname
                flist[current_pid]['meta_fname'] = meta_fname

                write_outfile(flist[current_pid]['tout_fname'], \
                              tok.value)

                thash = md5(path, flist[current_pid]['tout_fname'])

                write_outfile(flist[current_pid]['meta_fname'], \
                              "TRACE HASH: {0}\n".format(thash))

                found_list.append(flist[current_pid]['tout_fname'])
                fp_tmeta.write("E:{0}:{1}:{2}\n".format(current_pid, \
                                                        tok.lineno, \
                                                        thash))
                flist.pop(current_pid)

            elif tok.type == "TLINE":
                tout_buf[current_pid].append("{0}{1}\n".format(" "*2*nrspaces[current_pid], \
                                                               tok.value))

            elif tok.type == "WQSTART":
                wq = tok.value.split(':')[1].replace("work struct ","")
                wq = wq.replace(" ","")
                func = tok.value.split('function ')[1].replace(' ##', '')
                tout_buf[current_pid].append("{0}\n".format(tok.value))
                meta_buf[current_pid].append("AS:{0}:{1}, {2}\n".format(current_pid, \
                                                                tok.lineno, \
                                                                tok.value))
                fp_tmeta.write("AS:{0}:{1}, {2}\n".format(current_pid, \
                                                      tok.lineno, \
                                                      tok.value))
                tout_fname, \
                meta_fname = generate_filenames_wq(path, wq, func, hostname)

                flist[current_pid]['tout_fname'] = tout_fname
                flist[current_pid]['meta_fname'] = meta_fname

            elif tok.type == "ASYNCEND":
                meta_buf[current_pid].append("AE:{0}\n".format(tok.lineno))
                fp_tmeta.write("AE:{0}\n".format(tok.lineno))

            elif tok.type == "INTSTART":
                meta_buf[current_pid].append("IS:{0}\n".format(tok.lineno))
                fp_tmeta.write("IS:{0}\n".format(tok.lineno))

            elif tok.type == "INTEND":
                meta_buf[current_pid].append("IE:{0}\n".format(tok.lineno))
                fp_tmeta.write("IE:{0}\n".format(tok.lineno))

            elif tok.type == "TSWITCH":
                fp_tmeta.write("T:{0}: {1}\n".format(tok.lineno, \
                                                     tok.value))
            elif tok.type == "SYS_ID":
                fp_tmeta.write("SYS_ID:{0}: {1}\n".format(tok.lineno, \
                                                          tok.value))
            elif tok.type == "TPID":
                current_pid = tok.value

            # update identation of ftrace data
            if tok.type == "BRAOPEN" or tok.type == "BRACLOSE" \
               or tok.type == "CALLEND" or tok.type == "ASYNCEND":
                nrspaces[current_pid] = int(tok.value[1])

    fp_tmeta.close()
    return found_list

