#!/bin/bash

(while true; do grep -re abc / 2>&1 > /dev/zero; done) &
(while true; do hackbench -l 100000 > /dev/zero; done) &

