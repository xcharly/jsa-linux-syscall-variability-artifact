gcc -Wall -shared -fPIC -ldl pre_load.c -o pre_load.so
