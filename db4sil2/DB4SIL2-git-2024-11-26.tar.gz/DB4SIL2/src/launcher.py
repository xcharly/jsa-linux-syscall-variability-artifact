#!/usr/bin/python3
import os
import time
import datetime
import argparse
import signal

parser = argparse.ArgumentParser()



parser.add_argument('--name', required=True,
         help='python3 test_client.py --name job_name')

#parser.add_argument('--reboot', required=False,
#         help='Reboot system after test default No')

parser.add_argument('--nfs', required=False,
                help='Data directory is a nfs export')


parser.add_argument('--runs', type=int, help='Number of runs to execute')
parser.add_argument('--cpu', type=int, help='CPU mask')
parser.add_argument('--cmd', required=True, help='Command to be executed')
parser.add_argument('--clean_up', required=False, help='Command to be executed')
parser.add_argument('--args', required=False, help='Command to be executed')
parser.add_argument('--del_raw', required=False, help='Delete raw file not used by launcher')
parser.add_argument('--stress', required=False, help='Stress in the background')
parser.add_argument('--ld', required=False, help='Use LD_PRELOAD')


start = False

def handler(signum, frame):
    global start
    start = True

def execute(cmd, args, core, runs, ld):
    global start
    if ld == 'yes':
        os.environ['LD_PRELOAD'] = os.path.join(os.getcwd(), "pre_load.so")
    timeout = 60
    pid = os.getpid()

    while(start == False):
        do_nothing = 0

    if core == 0:
        affinity = os.sched_getaffinity(pid)
        os.sched_setaffinity(pid, affinity)
    else:
        os.sched_setaffinity(pid, [core])
    my_env = os.environ

    if args == "None":
        os.execvp(cmd, [cmd])
    else:
        arg_lst = args.split(' ')
        arg_lst.insert(0, cmd)
        os.execvp(cmd, arg_lst)

if __name__ == '__main__':
    args = parser.parse_args()
    signal.signal(signal.SIGUSR1, handler)
    print("Launcher CPU: %s" % args.cpu)
    execute(args.cmd, args.args, args.cpu, args.runs, args.ld)
    f.close()
