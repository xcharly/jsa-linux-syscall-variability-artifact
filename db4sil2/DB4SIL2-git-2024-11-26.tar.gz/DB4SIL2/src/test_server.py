"""

test_server.py creates a number of worker threads that do post-processing of
raw tracing data collected by test_client.py.
"""
import threading, queue
import db4sil2config as cfg
import socket
import os
from signal import signal, SIGINT
import logger as l
import collections
import dill as pickle
from threading import Thread
import time
import struct
import sys
import shutil
import json
from worker_async_thread import handle_client
import sock_conn as sc
from time import sleep


import asyncio, socket


loop = asyncio.get_event_loop()


def init_test_server(config_file):
    """
    Init test_server -- read config file, start logger and workers
    """

    logger_queue = queue.Queue()


    port, num_sockets = cfg.get_server_config(config_file, "test_server", logger_queue)

    return port, logger_queue, num_sockets






async def run_server(server, config_file, logger_queue):
    while True:
        client, _ = await loop.sock_accept(server)
        loop.create_task(handle_client(client, loop, config_file, logger_queue))



def server_code():
    """
    test_server
    """

    config_file = 'db4sil2.cfg'
    port, logger_queue, num_sockets = init_test_server(config_file)

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(('0.0.0.0', port))
    server.listen(num_sockets)
    server.setblocking(False)

    loop.run_until_complete(run_server(server, config_file, logger_queue))

    l.log_a_msg("test_server shutdown.", "INFO", logger_queue, "test_server")



if __name__ == '__main__':
    server_code()

