"""
Helper functions for parsing the configuration file.
"""

import configparser
import re
import logger as l
import platform

def get_test_config(configfile, tname, loggerq):
    """
    returns all information on tests, this includes:
        - list of test executables
	- ftrace path
        - number of test runs
        - testmode (suiteiteration vs. testiteration)
        - maximum allowed backlog before starting another round of tests.
    """
    tracingpath = "/sys/kernel/tracing"
    testfile = None
    testexec_list = []
    num_runs = 1
    testmode = "testiteration"
    backlog = 200
    reboot_client = "no"


    try:
        config = configparser.ConfigParser()
        config.read(configfile)

        check = config.has_option('general', 'tracingpath')
        if check:
            tracingpath = config.get('general', 'tracingpath')


    except configparser as err:
        l.log_a_msg(err, "ERROR", loggerq, tname)

    return tracingpath

def get_postprocessing_config(configfile, tname, loggerq):
    """
    get post-processing related configuration data, this includes:
        - A list of system calls that shall be considered,
        - the hostname of the client that produced the traces,
        - a flag that indicates whether or not raw traces shall be
          deleted after processing (or be kept for debugging).
    """
    syscalls_list = {}
    del_raw = True
    hostname = "noone"
    try:
        config = configparser.ConfigParser()
        config.read(configfile)

        check = config.has_option('general', 'supported_archs')
        if check:
            archs = [i.strip() for i in config.get('general', 'supported_archs').split(',')]



        for arch in archs:
            check = config.has_option('postprocessing', 'syscalls_%s' % arch)
            if check:
                syscalls_list.update({arch: []})
                syscalls_raw = re.sub('\n', '', config.get('postprocessing', \
                                                           'syscalls_%s' % arch))
                syscalls_rawlist = syscalls_raw.split(',')
                for syscall in syscalls_rawlist:
                    syscalls_list[arch].append(str(syscall).rstrip().lstrip())

        check = config.has_option('general', 'tested_kernels')
        if check:
            tested_kernels = [i.strip() for i in config.get('general', 'tested_kernels').split(',')]

        check = config.has_option('postprocessing', 'delete_raw_data')
        if check:
            del_raw = int(config.getboolean('postprocessing', \
                                            'delete_raw_data'))

    except configparser as err:
        l.log_a_msg(err, "ERROR", loggerq, tname)

    return syscalls_list, del_raw, tested_kernels


def get_client_config(configfile, tname, loggerq):
    """
    The test_client needs a servername and server to which it shall
    connect and pass finished raw traces to.
    """
    servername = "localhost"
    serverport = 50007

    try:
        config = configparser.ConfigParser()
        config.read(configfile)

        check = config.has_option('network', 'servername')
        if check:
            servername = config.get('network', 'servername')
        check = config.has_option('network', 'serverport')
        if check:
            serverport = int(config.get('network', 'serverport'))

        check = config.has_option('general', 'nfs')
        if check:
            nfs = config.get('general', 'nfs')



    except configparser as err:
        l.log_a_msg(err, "ERROR", loggerq, tname)

    return servername, serverport, nfs

def get_server_config(configfile, tname, loggerq):
    """
    The test_server only needs a port to listen to as network configuration
    this info is returned by get_server_config().
    """
    serverport = 50007

    try:
        config = configparser.ConfigParser()
        config.read(configfile)

        check = config.has_option('network', 'serverport')
        if check:
            serverport = int(config.get('network', 'serverport'))

        check = config.has_option('general', 'num_sockets')
        if check:
            num_sockets = int(config.get('general', 'num_sockets'))


    except configparser as err:
        l.log_a_msg(err, "ERROR", loggerq, tname)

    return serverport, num_sockets
