"""
test_client.py -- the sensor of DB4SIL2 which runs the testexecutables
and collects the raw traces of these runs.
"""

import os
import time
import sys
import queue
import struct
import platform
import json
import yaml
import argparse
import subprocess
import signal
from time import sleep
import socket
import logger as l
import ftrace_session as fs
import db4sil2config as cfg
import datetime
import dill as pickle
import sock_conn as sc



# pylint does not seem to like the python3 print style, so disable the
# message triggered by the parentheses of print():
#pylint: disable=superfluous-parens


parser = argparse.ArgumentParser(prog='PROG')
parser.add_argument('--name', required=True, help='Job name')

parser.add_argument('--server', required=True, help='DB4Sil2 server address help')
parser.add_argument('--port', type=int, required=True, help='DB4Sil2 server port address')
parser.add_argument('--reboot', required=False, help='Reboot after finish')
parser.add_argument('--nfs', required=False, default='no', help='Store data to nfs share')
parser.add_argument('--del_raw', required=False, default='yes', help='Delete raw after test')
parser.add_argument('--wq', required=False, default='no', help='Trace workqueues')

parser.add_argument('--ld', required=True, help='Preload library')

subparsers = parser.add_subparsers(help='sub-command help', required = True, dest = 'cmd')

# create the parser for the "a" command
parser_load = subparsers.add_parser('load', help='Execute Load script')
parser_load.add_argument('--yml', type=str, help='YAML job description')

parser_job = subparsers.add_parser('job', help='Execute single binary')
parser_job.add_argument('--runs', type=int, help='Number of runs to execute')
parser_job.add_argument('--core', type=int, default=0, help='Number of runs to execute')
parser_job.add_argument('--cmd', type=str, help='Binary to execute with complete path')
parser_job.add_argument('--stress', type=str, help='Load to execute the test')
parser_job.add_argument('--args', type=str, required=False, help='Arguments for binary to be executed')
parser_job.add_argument('--clean_up', type=str, default='no', help='Command to clean-up generated data')

# python3 test_client.py --name  blue --server localhost --port 4714 load --yml load_example.yml



# a sample dictionary data
data = {'data number': 0,
        'message': 'A new message has been arrived from client'}




def send_data(conn, nfs, test_tracefile):
    #
    # set trace file name
    data['data number'] += 1

    sc.send_data(conn, test_tracefile.split('/')[-1:][0], \
                    sc.data_identifiers['name'])
    payload = sc.receive_data(conn)[1]

    # send trace data
    if nfs == 'no':
        with open(test_tracefile, 'r') as f:
            trace_data = f.read()
            sc.send_data(conn, trace_data, sc.data_identifiers['trace'])
        payload = sc.receive_data(conn)[1]
    else:
        # send empty to trigger post process
        sc.send_data(conn, '', sc.data_identifiers['trace'])

    sc.send_data(conn, 'tests done', sc.data_identifiers['end'])
    conn.close()


def setup_tracer(tracepath, logger_queue, wqueue):
    testtrace = fs.FtraceSession(tracepath, logger_queue)
    testtrace.reset_ftrace()
    testtrace.set_tracer("function_graph")
    testtrace.set_trace_option("funcgraph-proc")
    testtrace.set_trace_option("noirq-info")
    testtrace.set_trace_option("nofuncgraph-irqs")
    if wqueue == 'yes':
        testtrace.set_trace_event("workqueue")
    return testtrace

async def gather_pids(pid_lst):
    for pid in pid_lst:
        if not psutil.pid_exists(pid):
            pid_lst.pop(pid_lst.index(pid))
    return

def get_load_info(file_name):
    if os.path.isfile(file_name):
        with open(file_name,'r') as f:
            data = yaml.load(f, Loader=yaml.FullLoader)
        return data
    else:
        return None


def wait_for_pids(process_lst, pid_lst):
    while(True):
        for p in process_lst:
            if p.poll() != None:
                pid_lst.pop(pid_lst.index(p.pid))
        if len(pid_lst) == 0:
            break

def clean_up(v):
    if 'clean_up' in v.keys():
        if v['clean_up'] != 'no':
            os.system(v['clean_up'])



def do_job(job, job_type, jargs, runs, is_parallel):
    """
    actual "main()"
    """
    launcher_bin = os.path.join(os.getcwd(), 'launcher.py')
    if is_parallel == True:
        args = []
        for k,v in job.items():
            a = [launcher_bin, '--name', jargs.name]
            for kk, vv in v.items():
                a.append('--' + kk)
                a.append(str(vv))
            args.append(a)
    else:
        args = [launcher_bin, '--name', jargs.name, '--cmd', job_type]
        for k, v in job.items():
            args.append('--' + k)
            args.append(str(v))

    logger_queue = queue.Queue()
    # Before we do anything else: start the logger thread, so we can log
    # whats going on
    threadid = 1
    logger_t = l.DB4SIL2Logger(threadid, "logger", logger_queue, \
                               "db4sil2_client.log")
    logger_t.daemon = True # make the logger thread a daemon, this way the main
                           # will clean it up before terminating!
    logger_t.start()

    tracepath = cfg.get_test_config('db4sil2.cfg', \
                                    'test_client', \
                                    logger_queue)

    if not os.path.exists(tracepath):
        print("Tracing not correct configured")
        sys.exit(-1)

    # Setup tracer
    testtrace = setup_tracer(tracepath, logger_queue, jargs.wq)

    conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    conn.connect((jargs.server, jargs.port))
    sc.send_data(conn, sc.key_message)
    _id, first_payload = sc.receive_data(conn)
    dst_path = ''

    if first_payload == 'You are not authorized':
        print('[ERROR]: Access denied')
    else:
        # send machine info
        data['data number'] += 1
        mdata = {'arch': platform.uname().machine,
                 'kernel': platform.uname().release,
                 'hostname': platform.uname().node,
                 'del_raw': jargs.del_raw,
                 'runs': runs,
                 'nfs': jargs.nfs,
                 'job_name': jargs.name}

        sc.send_data(conn, json.dumps(mdata), sc.data_identifiers['data'])
        payload = sc.receive_data(conn)[1]

        if payload == 'Abort':
            conn.close
            return
        if jargs.nfs == 'yes':
            dst_path = payload
        else:
            dst_path = './'

        if jargs.stress != None:
            cmd_stress = jargs.stress
            p_stress = subprocess.Popen(cmd_stress.split())
            l.log_a_msg("System stress: %s" % jargs.stress, "INFO", logger_queue, "test_client")
        l.log_a_msg("Launching tests with %d runs" % runs, "INFO", logger_queue, "test_client")


        for run in range(0, runs):
            print("test_client run %d of %d" % (run + 1, runs))
            process_lst = []
            if is_parallel:
                for job_args in args:
                    p = subprocess.Popen(job_args)
                    process_lst.append(p)
            else:
                p = subprocess.Popen(args, shell=False)
                process_lst.append(p)

            sleep(5)
            str_pids = [str(process.pid) for process in process_lst]
            pid_lst = [process.pid for process in process_lst]
            pid_lst_str = ", ".join(str_pids)

            testtrace.start_trace(pid_lst_str, jargs.wq)

            for process in process_lst:
                process.send_signal(signal.SIGUSR1)

            wait_for_pids(process_lst, pid_lst)

            current_t = datetime.datetime.now()
            formatted_dt = current_t.strftime("%Y-%m-%d_%H%M%S%f")
            test_tracefile = "{0}test_trace_{1}".format(dst_path, formatted_dt)


            if jargs.nfs == 'no':
                testtrace.stop_and_store_trace(test_tracefile, jargs.name)
                print('test_tracefile: %s' % test_tracefile)
                sc.send_data(conn, test_tracefile, sc.data_identifiers['name'])

                with open(test_tracefile, 'r') as f:
                    trace_data = f.read()

                sc.send_data(conn, trace_data, sc.data_identifiers['trace'])
                if jargs.del_raw == 'yes':
                    os.remove(test_tracefile)
            else:
                testtrace.stop_and_store_trace('./' + test_tracefile, jargs.name)
                print('test_tracefile: %s' % test_tracefile)
                sc.send_data(conn, test_tracefile, sc.data_identifiers['name'])

                sc.send_data(conn, 'process', sc.data_identifiers['trace'])

        sc.send_data(conn, 'tests done', sc.data_identifiers['end'])
        conn.close()

        # call clean up routine
        if job_type == 'load':
            if is_parallel == True:
                for k, v in job.items():
                    clean_up(v)
            else:
                clean_up(job)
        else:
            clean_up(job)

        # kill stress proccess
        if jargs.stress != None:
            os.kill(p_stress.pid, signal.SIGTERM)

        if jargs.reboot == 'yes':
            os.system('/sbin/reboot')

### main ###
if __name__ == '__main__':
    args = parser.parse_args()
    if args.cmd == 'load':
        load = get_load_info(args.yml)
        it_is = ''
        for k,v in load.items():
            flag = False
            for kk, vv in v.items():
                if isinstance(vv, dict):
                    flag = True
            # pop runs out of dict to avoid trouble later on!
            runs = v['runs']
            e = v
            e.pop('runs')
            do_job(e, args.cmd, args, runs, flag)
    else:
        job = {'runs': args.runs,
               'cpu': args.core,
               'args': args.args,
               'ld' : args.ld,
               'stress': args.stress,
               'del_raw': args.del_raw,
               'clean_up': args.clean_up}
        do_job(job, args.cmd, args, args.runs, False)
