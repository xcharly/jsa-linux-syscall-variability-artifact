#define _GNU_SOURCE
#include <dirent.h>
#include <dlfcn.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <syslog.h>
#include <unistd.h>
#include <stdlib.h>
#include <dlfcn.h>
#include <execinfo.h>
#include <stddef.h>
#include <link.h>
#include <assert.h>
#include <sys/types.h>
#include <stdarg.h>
#include <errno.h>

//#define TRACE_MARKER_PATH "/tmp/blx.txt"
#define TRACE_MARKER_PATH "/sys/kernel/tracing/trace_marker"
       #define BT_BUF_SIZE 100

/* We cannot include fcntl.h, this would collide with open */
#define O_RDONLY        0       /* Open read-only.  */
#define O_WRONLY        1       /* Open write-only.  */
#define O_RDWR          2       /* Open read/write.  */


static int (*real_open)(const char *str, int flags, ...) = NULL;
//static int (*real_open)(const char *str, int flags, mode_t mode) = NULL;
ssize_t (*real_read)(int, void*, size_t) = NULL;
static ssize_t (*real_write)(int fd, const void *buf, size_t count) = NULL;
static int (*real_close)(int fd) = NULL;

static FILE *(*real_fopen)(const char *pathname, const char *mode) = NULL;
static FILE *(*real_fopen64)(const char *str, const char *mode) = NULL;
static size_t (*real_fread)(void *ptr, size_t size, size_t nmemb, FILE *stream) = NULL;
static size_t (*real_fwrite)(const void *ptr, size_t size, size_t nmemb, FILE *stream) = NULL;
static int (*real_fclose)(FILE *fp) = NULL;



void find_info(char * txt, const char * call)
{
    unsigned int length = 0;
    char *ptr = txt;
    char *addr_start = NULL;
    unsigned int found = 0;
    char buffer[60];
    char binary[60];
    int addr = 0;
    char *obuffer;
    int marker_fd = -1;

    for (int i=0; i < strlen(txt); i++){
        if (*ptr == '(') {
            memcpy(binary, txt, i);
            binary[i] = '\0';
	    addr_start = ptr + 2;
            ptr = ptr + 2;
            found = 1;
        }
        if (*ptr == ')') {
            memcpy(buffer, addr_start, length);
            addr = strtol(buffer, NULL, 16);
            break;
        }
        if (found == 1)
            length++;
        ptr++;
    }
	char *error;
    asprintf(&obuffer,"db4sil2_sys_start:%s:%s:%d", binary, call, addr);
	dlerror();
	real_open = dlsym(RTLD_NEXT, "open");
	if ((error = dlerror()) != NULL)  {
        fprintf(stderr, "ERROR: %s\n", error);
    }
	real_write = dlsym(RTLD_NEXT, "write");
	real_close = dlsym(RTLD_NEXT, "close");
	marker_fd = real_open(TRACE_MARKER_PATH, O_WRONLY);
	real_write(marker_fd, obuffer, strlen(obuffer));
	real_close(marker_fd);
    free(obuffer);
}

void insert_marker(const char *call)
{
    int nptrs;
    void *buffer[BT_BUF_SIZE];
    char **strings;

    nptrs = backtrace(buffer, BT_BUF_SIZE);

    /* The call backtrace_symbols_fd(buffer, nptrs, STDOUT_FILENO)
       would produce similar output to the following: */

    strings = backtrace_symbols(buffer, nptrs);
    if (strings == NULL) {
        perror("backtrace_symbols");
        exit(EXIT_FAILURE);
    }

	find_info(strings[2], call);
    free(strings);
}


int open(char const *str, int oflag, ...) {
	va_list args;
    int mflag;
  	if (!real_open) {
    	real_open = dlsym(RTLD_NEXT, __func__);
  	}
  	insert_marker(__func__);
    va_start(args, oflag);
    mflag = va_arg(args, int);
    return real_open(str, oflag, mflag);
}

ssize_t read(int fd, void *buf, size_t count) {
    if(!real_read) {
		real_read = dlsym(RTLD_NEXT, "read");
	}
    insert_marker(__func__);
    return real_read(fd, buf, count);
}

ssize_t write(int fildes, const void *buf, size_t nbytes) {
    if (!real_write) {
		real_write = dlsym(RTLD_NEXT, "write");
	}
    insert_marker(__func__);
    return real_write(fildes, buf, nbytes);
}

int close(int fd) {
    if (!real_close) {
		real_close = dlsym(RTLD_NEXT, "close");
    }
    insert_marker(__func__);

    return real_close(fd);
}
/* fopen | fopen64 | fread | fwrite | flcose */

FILE *fopen(const char *pathname, const char *mode) {
    if (!real_fopen) {
        real_fopen = dlsym(RTLD_NEXT, __func__);
    }
    insert_marker(__func__);
    return real_fopen(pathname, mode);
}
 
FILE *fopen64(const char *str, const char *mode) {
    if (!real_fopen64) {
  	    real_fopen64 = dlsym(RTLD_NEXT, __func__);
    }
    insert_marker(__func__);
    return real_fopen64(str, mode);
}

size_t fread(void *ptr, size_t size, size_t nmemb, FILE *stream) {
    if (!real_fread) {
  	    real_fread = dlsym(RTLD_NEXT, __func__);
    }
    insert_marker(__func__);
    return real_fread(ptr, size, nmemb, stream);
}

size_t fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream) {
    if(!real_fwrite) {
  	    real_fwrite = dlsym(RTLD_NEXT, __func__);
    }
    insert_marker(__func__);
    return real_fwrite(ptr, size, nmemb, stream);
}

int fclose(FILE *fp) {
    if (!real_fclose) {
        real_fclose = dlsym(RTLD_NEXT, __func__);
    }
    insert_marker(__func__);
    return real_fclose(fp);
}
