import struct
import dill as pickle

import asyncio, socket




key_message = 'C0nn3c+10n'
data_identifiers = {'info': 0, 'data': 1, 'name': 2, 'trace':3, 'end':4}


"""
This function with MIT License was taken from:
https://github.com/vijendra1125/Python-Socket-Programming
"""

async def send_data(loop, client, payload, data_id=0):
    '''
    @brief: send payload along with data size and data identifier to the connection
    @args[in]:
        conn: socket object for connection to which data is supposed to be sent
        payload: payload to be sent
        data_id: data identifier
    '''
    # serialize payload
    serialized_payload = pickle.dumps(payload)
    # send data size, data identifier and payload
    await loop.sock_sendall(client, struct.pack('>I', len(serialized_payload)))
    await loop.sock_sendall(client, struct.pack('>I', data_id))
    await loop.sock_sendall(client, serialized_payload)



"""
This function with MIT License was taken from:
https://github.com/vijendra1125/Python-Socket-Programming
"""
async def receive_data(loop, client):
    '''
    @brief: receive data from the connection assuming that
        first 4 bytes represents data size,
        next 4 bytes represents data identifier and
        successive bytes of the size 'data size'is payload
    @args[in]:
        conn: socket object for conection from which data is supposed to be received
    '''
    # receive first 4 bytes of data as data size of payload
    #data_size = struct.unpack('>I', conn.recv(4))[0]
    data = await loop.sock_recv(client, 4)
    data_size = struct.unpack('>I', data)[0]
    data = await loop.sock_recv(client, 4)
    data_id = struct.unpack('>I', data)[0]
    # receive payload till received payload size is equal to data_size received
    received_payload = b""
    reamining_payload_size = data_size
    while reamining_payload_size != 0:
        received_payload += (await loop.sock_recv(client, reamining_payload_size))
        reamining_payload_size = data_size - len(received_payload)
    payload = pickle.loads(received_payload)
    return (data_id, payload)

