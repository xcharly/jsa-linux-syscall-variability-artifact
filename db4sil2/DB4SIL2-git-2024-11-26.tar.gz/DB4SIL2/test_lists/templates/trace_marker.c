#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#define TRACE_MARKER_PATH "/sys/kernel/tracing/trace_marker"

int main(int argc, char **argv) {
    char buff[32] = {0};
    int fd1 = -1;
    int fd2 = -1;
    int marker_fd = -1;
    int ret = -1;
    
    char id_start[30];
    char id_end[30];

    marker_fd = open(TRACE_MARKER_PATH, O_WRONLY);

    fd1 = open("/dev/urandom", O_RDONLY);
    fd2 = open("/dev/zero", O_WRONLY);
    
    strcpy(id_start, "db4sil2_sys_start: read");
    write(marker_fd, id_start, sizeof(id_start)); 
    ret = read(fd1, buff, 32);
    strcpy(id_end, "db4sil2_sys_end: read");
    write(marker_fd, id_end, sizeof(id_end)); 

    strcpy(id_start, "db4sil2_sys_start: write");
    write(marker_fd, id_start, sizeof(id_start)); 
    ret = write(fd2, buff, 32);
    strcpy(id_end, "db4sil2_sys_end: write");
    write(marker_fd, id_end, sizeof(id_end)); 
    
    close(fd1);
    close(fd2);
    close(marker_fd);
    return 0;
}

