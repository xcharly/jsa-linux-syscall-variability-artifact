#!/bin/sh

TDIR1=/tmp/0/1/2/3/4/5/6/7/8/9
TDIR2=/tmp/1/2/3/4/5/6/7/8/9/0
VDIR1=/root/0/1/2/3/4/5/6/7/8/9
VDIR2=/root/1/2/3/4/5/6/7/8/9/0

mkdir -p $TDIR1 $TDIR2
mkdir -p $VDIR1 $VDIR2
dd if=/dev/zero of=/tmp/tmpdata bs=1024k count=10 2>/dev/null
dd if=/dev/zero of=/root/tmpdata bs=1024k count=10 2>/dev/null

touch /tmp/ifile
