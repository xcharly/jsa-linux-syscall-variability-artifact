#!/usr/bin/python2.7

import re
import collections
import pandas
import seaborn as sns
import numpy as np
#from ggplot import *
import matplotlib.pyplot as plt

from itertools import product
from string import ascii_uppercase
from matplotlib import patheffects

trace_dists = collections.defaultdict(dict)

def read_data_file(filename):
    with open(filename) as fp:
        for line in fp:
            if re.search("---RUN [0-9]*---", line):
                tmp = line.replace("---RUN ", "")
                runnr = int(tmp.replace("---\n", ""))
            #    print("NEW RUN: '{0}'".format(runnr))
            else:
                trace_hash = line[10:-1]
                trace_dists[runnr][trace_hash] = int(line[:9].strip())
            #    print(trace_hash,  int(line[:9].strip()))


read_data_file("suiteiter_SyS_brk.dat")

df=pandas.DataFrame(trace_dists)
df.fillna(0, inplace=True)
#print(df.index)
#print(df.columns)
#sns.heatmap(df)
#ggplot(aes(x=df.columns.all(), y=df.index.all()), df)
m = len(df.index)
n = len(df.columns)
ax = plt.imshow(df, interpolation='nearest', cmap='Oranges').axes

_ = ax.set_xticks(np.linspace(0, n-1, n))
_ = ax.set_xticklabels(df.columns)
_ = ax.set_yticks(np.linspace(0, m-1, m))
_ = ax.set_yticklabels(df.index)

ax.grid('off')
ax.xaxis.tick_top()
