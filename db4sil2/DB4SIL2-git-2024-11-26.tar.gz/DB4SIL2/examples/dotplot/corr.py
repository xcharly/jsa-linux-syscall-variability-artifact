#!/usr/bin/python3

import re
import collections
import pandas

from itertools import combinations

def read_data_file(filename, trace_dists, runoffset):
    with open(filename) as fp:
        for line in fp:
            if re.search("---RUN [0-9]*---", line):
                tmp = line.replace("---RUN ", "")
                runnr = int(tmp.replace("---\n", "")) + runoffset
            else:
                trace_hash = line[9:-1]
                trace_dists[runnr][trace_hash] = int(line[:9].strip())
    return trace_dists

trace_dists = collections.defaultdict(dict)
trace_dists = read_data_file("suiteiter_SyS_read.dat", trace_dists, 0)
#trace_dists = read_data_file("testiter_SyS_read.dat", trace_dists, 0)

df = pandas.DataFrame(trace_dists)


# if we sort by the first distribution of the first trace we *SHOULD* sort all the
# traces (with few exceptions) -- but the likely traces should be nicely arranged
# and exceptions easy to spot.
df.sort_values(by=list(df.columns), ascending=False, inplace=True)
#dfprop.to_csv("uniquetraces_SyS_read", sep='\t')
##calculate propabilities
dfprop = 1/sum(df.sum()) * df
dfprop.fillna(0, inplace=True)

not_nan_count = df.count(axis=1)
excludes = []
for idx in not_nan_count.index:
    if not_nan_count[idx] == len(df.columns):
        excludes.append(idx)

print("EXCLUDES: {0}".format(excludes))

maxval=0

prop_bound = 1/len(df.columns) /10
print(prop_bound)

for i, j in combinations(dfprop.index, 2):
    if not (dfprop[1][i] > prop_bound or dfprop[1][j] > prop_bound):
#    if not (i in excludes and j in excludes):
        
        psum = 0
        for k in dfprop.columns:
            if dfprop[k][j]:
                psum += dfprop[k][j]
        if psum >= 0.05:
            print(i,j, psum)
        if psum > maxval:
            maxval = psum
    else:
        print("SKIPPED PAIR: {0}, {1}".format(i,j))

print("Max: {0}".format(maxval))

