#!/usr/bin/python3

import re
import collections
import pandas
import matplotlib.pyplot as plt


def read_data_file(filename, trace_dists):
    with open(filename) as fp:
        for line in fp:
            if re.search("---RUN [0-9]*---", line):
                tmp = line.replace("---RUN ", "")
                runnr = int(tmp.replace("---\n", ""))
            #    print("NEW RUN: '{0}'".format(runnr))
            else:
                trace_hash = line[10:-1]
                trace_dists[runnr][trace_hash] = int(line[:9].strip())
            #    print(trace_hash,  int(line[:9].strip()))

    return trace_dists


suiteiter_trace_dists = collections.defaultdict(dict)
suiteiter_trace_dists = read_data_file("suiteiter_SyS_brk.dat", suiteiter_trace_dists)

df_suite = pandas.DataFrame(suiteiter_trace_dists)
#df_suite.fillna(0, inplace=True)
df_suite.sort_index(by=list(df_suite.columns), ascending=False, inplace=True)


x = []
y = []
s = []

for xind in df_suite.columns:
    for yind in range(0,len(df_suite)):
        tmpval = df_suite.ix[df_suite.index[yind], xind]
        if tmpval > 0:
            x.append(xind)
            y.append(yind)
#            if tmpval >= 1 and tmpval < 10:
#                s.append(2)
#                ts=2
#            elif tmpval > 10 and tmpval < 100:
#                s.append(4)
#                ts=4
#            else:
#                s.append(200)
#                ts=200
            s.append(3*tmpval)
#            print(xind, yind, tmpval, ts)

plt.scatter(x,y,s=s)
plt.grid(True)
plt.yticks(range(0,len(df_suite)), df_suite.index, fontsize="small")
plt.show()
