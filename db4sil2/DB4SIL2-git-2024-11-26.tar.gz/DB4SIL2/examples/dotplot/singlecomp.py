#!/usr/bin/python3

import re
import collections
import pandas
import seaborn as sns
import matplotlib.pyplot as plt

from itertools import combinations

def read_data_file(filename, trace_dists, runoffset):
    with open(filename) as fp:
        for line in fp:
            if re.search("---RUN [0-9]*---", line):
                tmp = line.replace("---RUN ", "")
                runnr = int(tmp.replace("---\n", "")) + runoffset
            #    print("NEW RUN: '{0}'".format(runnr))
            else:
                trace_hash = line[9:-1]
                trace_dists[runnr][trace_hash] = int(line[:9].strip())
            #    print(trace_hash,  int(line[:9].strip()))

    return trace_dists

trace_dists = collections.defaultdict(dict)
trace_dists = read_data_file("suiteiter_SyS_mmap.dat", trace_dists, 0)

#for i in range(1,10):
#    trace_dists[len(trace_dists.keys())+i] = {}

#trace_dists = read_data_file("testiter_SyS_mmap.dat", trace_dists, len(trace_dists)+10)

df = pandas.DataFrame(trace_dists)


# if we sort by the first distribution of the first trace we *SHOULD* sort all the
# traces (with few exceptions) -- but the likely traces should be nicely arranged
# and exceptions easy to spot.
df.sort_values(by=list(df.columns), ascending=False, inplace=True)

##calculate propabilities
dfprop = 1/df.sum() * df
#print(df[4])
#df[16].to_csv("uniquetraces_SyS_mmap", sep='\t')

not_nan_count = df.count(axis=1)
rare_traces = []
for idx in not_nan_count.index:
    if not_nan_count[idx] == 1:
        rare_traces.append(idx)

print(rare_traces)
print(len(rare_traces))


#sns.heatmap(df)
pal = sns.dark_palette("red", as_cmap=True)
sns.heatmap(dfprop, cmap=pal)
#sns.heatmap(df, annot=True, cmap=pal)
plt.yticks(rotation=0)

sns.plt.show()

