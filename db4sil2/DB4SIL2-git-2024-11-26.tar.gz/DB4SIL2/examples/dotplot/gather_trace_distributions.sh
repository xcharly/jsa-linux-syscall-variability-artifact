#!/bin/bash

SYSCALLS="SyS_brk SyS_write SyS_read SyS_mmap SyS_access SyS_rt_sigprocmask SyS_newstat SyS_set_robust_list SyS_lseek SyS_getrlimit SyS_rt_sigaction sys_arch_prctl"

for SYSCALL in $SYSCALLS
do

    for LOOPCNT in $(seq 1 100)
    do

        cd RUN_suiteiter_$LOOPCNT/syscalls/meta/$SYSCALL > /dev/null

        echo "---RUN $LOOPCNT---" >> ../../../../suiteiter_$SYSCALL.dat
        ls  | xargs cat | egrep "TRACE HASH: " | cut -d ":" -f2 | sort | uniq -c | sort -n >> ../../../../suiteiter_$SYSCALL.dat
        cd - > /dev/null

    done

    for LOOPCNT in $(seq 1 91)
    do

        cd RUN_testiter_$LOOPCNT/syscalls/meta/$SYSCALL > /dev/null

        echo "---RUN $LOOPCNT---" >> ../../../../testiter_$SYSCALL.dat
        ls  | xargs cat | egrep "TRACE HASH: " | cut -d ":" -f2 | sort | uniq -c | sort -n >> ../../../../testiter_$SYSCALL.dat
        cd - > /dev/null

    done
done 
